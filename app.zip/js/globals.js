globals = {}

globals.app_name = "promo 2"
globals.google_analytics = "UA-56920705-3"

