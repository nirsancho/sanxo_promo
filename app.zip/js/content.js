var default_content = {
    "approval": {
        "body": "<p>Al aprobar leenviamos un menssaje bla</p>",
        "dialog": "si dice si esta aprobando",
        "dialog_title": "Permite compartir?",
        "question": "cerca boton",
        "url": "https://www.powr.io/plugins/form-builder/view?id=276960"
    },
    "create_page": {},
    "create_pages": {},
    "get_content": {},
    "pages": [{
        "body": "<p>5</p>",
        "title": "Bienvenido 5"
    }, {
        "body": "<p>5<br></p>",
        "title": "5¿Como funciona?"
    }, {
        "body": "<p>formulario contenido</p>",
        "title": "formulario datos"
    }, {
        "body": "Gracias",
        "title": "Ultima"
    }]
};
