navigator = {};
navigator.notification = {};
navigator.contacts = {};

navigator.load_timestamp = new Date().getTime();

navigator.log = function (str) {
    if (typeof str == "string") {
        str = parseInt((new Date().getTime() - navigator.load_timestamp) / 1000) + " (emulated): " + str;
    }
    console.log(str);
}
navigator.notification.beep = function (times) {
    for (var i = 0; i < times; i++) {
        navigator.log("beep");
    }
}

navigator.notification.alert = function (msg, callback, title) {
    alert(msg);
    if (callback) {
        callback();
    }
}

navigator.notification.confirm = function (msg, onclose, title, options) {
    navigator.log("confirm: " + msg);
    navigator.log("title: " + title);
    navigator.log(options);
    onclose(1);
}

navigator.contacts.find = function (fields, onSuccess, onError) {
    var demoContact = {
        displayName: "bob",
        phoneNumbers: [{
            "value": "12345678"
        }],
        emails: [{
            "value": "bob@bob.com"
        }]
    };
    var demoContacts = [];
    for (var i=0; i<1000; i++) {
        demoContact.displayName = "bob_"+i;
        demoContacts.push(demoContact);
    }
    onSuccess(demoContacts);
}
navigator.app = {};
navigator.app.loadUrl = function(url) {
    navigator.log("navigating to: " + url);
    window.location = url;
}