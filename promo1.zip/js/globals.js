globals = {}

globals.app_name = "promo 1"
globals.google_analytics = "UA-56920705-3"

