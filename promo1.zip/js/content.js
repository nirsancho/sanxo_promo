var default_content = {
    "approval": {
        "body": "Permitenos enviar esta oferta a tus contactos, si la aceptan podrás hablar con ellos gratis, sin limites de minutos.",
        "dialog": "NO: No le enviamos ningún mensaje a sus contactos",
        "dialog_title": "NO: No le enviamos ningún mensaje a sus contactos",
        "question": ""
    },
    "create_page": {},
    "create_pages": {},
    "get_content": {},
    "pages": [{
        "body": "Bienvenido a esta promoción",
        "enabled": true,
        "image": "",
        "title": "Bienvenido"
    }, {
        "body": "",
        "enabled": true,
        "image": "",
        "title": "Oferta"
    }, {
        "body": "",
        "enabled": true,
        "image": "",
        "title": "Formulario"
    }, {
        "body": "",
        "enabled": true,
        "image": "",
        "title": "Gracias"
    }]
};